package com.example.imagetotext;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class MainActivity extends AppCompatActivity {

    private TextRecognizer recognizer;
    private ScrollView scrollView;
    private TextView textOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the Text Recognizer
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        // Initialize Views
        scrollView = findViewById(R.id.scrollView);
        textOutput = findViewById(R.id.textOutput);
        ImageView capturedImageView = findViewById(R.id.capturedImageView);
        Button clearResults = findViewById(R.id.clearResults);
        ImageButton imageButton4 = findViewById(R.id.imageButton4);

        // Register activity result contract for taking picture preview
        ActivityResultLauncher<Void> takePicture = registerForActivityResult(
                new ActivityResultContracts.TakePicturePreview(), bitmap -> {
        if (bitmap != null) {
            // Display the image
            capturedImageView.setImageBitmap(bitmap);
            capturedImageView.setVisibility(View.VISIBLE);
            clearResults.setVisibility(View.VISIBLE);
            textOutput.setVisibility(View.VISIBLE);
            // Call text recognition
            recognizeText(bitmap);
        } else {
            // Handle case if bitmap is null
            textOutput.setText("Failed to capture image");
        }
    });

        // OnClick listener for imageButton4 to launch the camera
        imageButton4.setOnClickListener(v -> takePicture.launch(null));

        // OnClick listener for clearResults button to reset the UI
        clearResults.setOnClickListener(v -> {
        capturedImageView.setImageBitmap(null);
        capturedImageView.setVisibility(View.INVISIBLE);
        clearResults.setVisibility(View.INVISIBLE);
        textOutput.setVisibility(View.INVISIBLE);
    });
    }

    private void recognizeText(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
            .addOnSuccessListener(visionText -> processVisionText(visionText))
        .addOnFailureListener(e -> {
        e.printStackTrace();
        textOutput.setText("Error recognizing text: " + e.getLocalizedMessage());
    });
    }

    private void processVisionText(Text visionText) {
        StringBuilder stringBuilder = new StringBuilder();
        if (visionText.getTextBlocks().isEmpty()) {
            stringBuilder.append("No Text Detected!");
        } else {
            for (Text.TextBlock block : visionText.getTextBlocks()) {
                String text = block.getText();
                stringBuilder.append(text).append("\n");
            }
        }
        textOutput.setText(stringBuilder.toString());

        // Scroll down to the latest text output
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }
}
